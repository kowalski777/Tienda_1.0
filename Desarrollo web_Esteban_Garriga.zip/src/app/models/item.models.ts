export class ItemModel {
    nombre: string;
    precio: number;
    img: string;
    stock: number;
    cantidad: number;
    subTotal: number;
    id: string;

    constructor() {
                 this.nombre = this.nombre;
             }
  };